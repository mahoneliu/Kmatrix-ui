import{l as o,m as n,j as t,o as c}from"./main-DpEtK5Yz.js";const r={};function s(_,a){const e=n("RouterView");return c(),t(e)}const i=o(r,[["render",s]]);export{i as default};
