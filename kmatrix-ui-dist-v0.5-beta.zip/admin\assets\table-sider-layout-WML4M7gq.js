import{bI as le,cz as se,b4 as ae,b6 as D,af as c,ag as x,C as ne,d as L,L as g,cA as K,h as j,J as X,ai as F,cB as G,c as B,as as q,al as J,am as i,ah as P,bd as ie,c5 as ce,cc as Y,D as de,H as ue,G as W,K as E,cC as ge,j as M,g as O,o as V,w as f,e as T,a3 as be,x as he,cv as S,b as H,t as U,cD as fe,l as pe}from"./main-DpEtK5Yz.js";import{p as Q,l as me}from"./interface-D6M-WrBY.js";import{_ as ve,a as ye}from"./Grid-Dyd6kszb.js";import{N as Ce,a as xe}from"./CollapseItem-DZhg54KX.js";function Se(e){const{baseColor:o,textColor2:r,bodyColor:a,cardColor:l,dividerColor:d,actionColor:v,scrollbarColor:_,scrollbarColorHover:y,invertedColor:b}=e;return{textColor:r,textColorInverted:"#FFF",color:a,colorEmbedded:v,headerColor:l,headerColorInverted:b,footerColor:v,footerColorInverted:b,headerBorderColor:d,headerBorderColorInverted:b,footerBorderColor:d,footerBorderColorInverted:b,siderBorderColor:d,siderBorderColorInverted:b,siderColor:l,siderColorInverted:b,siderToggleButtonBorder:`1px solid ${d}`,siderToggleButtonColor:o,siderToggleButtonIconColor:r,siderToggleButtonIconColorInverted:r,siderToggleBarColor:D(a,_),siderToggleBarColorHover:D(a,y),__invertScrollbar:"true"}}const Z=le({name:"Layout",common:ae,peers:{Scrollbar:se},self:Se}),_e=c("layout",`
 color: var(--n-text-color);
 background-color: var(--n-color);
 box-sizing: border-box;
 position: relative;
 z-index: auto;
 flex: auto;
 overflow: hidden;
 transition:
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
`,[c("layout-scroll-container",`
 overflow-x: hidden;
 box-sizing: border-box;
 height: 100%;
 `),x("absolute-positioned",`
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `)]),Te={embedded:Boolean,position:Q,nativeScrollbar:{type:Boolean,default:!0},scrollbarProps:Object,onScroll:Function,contentClass:String,contentStyle:{type:[String,Object],default:""},hasSider:Boolean,siderPlacement:{type:String,default:"left"}},ee=ne("n-layout");function oe(e){return L({name:e?"LayoutContent":"Layout",props:Object.assign(Object.assign({},F.props),Te),setup(o){const r=j(null),a=j(null),{mergedClsPrefixRef:l,inlineThemeDisabled:d}=X(o),v=F("Layout","-layout",_e,Z,o,l);function _(u,h){if(o.nativeScrollbar){const{value:p}=r;p&&(h===void 0?p.scrollTo(u):p.scrollTo(u,h))}else{const{value:p}=a;p&&p.scrollTo(u,h)}}J(ee,o);let y=0,b=0;const R=u=>{var h;const p=u.target;y=p.scrollLeft,b=p.scrollTop,(h=o.onScroll)===null||h===void 0||h.call(o,u)};G(()=>{if(o.nativeScrollbar){const u=r.value;u&&(u.scrollTop=b,u.scrollLeft=y)}});const w={display:"flex",flexWrap:"nowrap",width:"100%",flexDirection:"row"},$={scrollTo:_},z=B(()=>{const{common:{cubicBezierEaseInOut:u},self:h}=v.value;return{"--n-bezier":u,"--n-color":o.embedded?h.colorEmbedded:h.color,"--n-text-color":h.textColor}}),C=d?q("layout",B(()=>o.embedded?"e":""),z,o):void 0;return Object.assign({mergedClsPrefix:l,scrollableElRef:r,scrollbarInstRef:a,hasSiderStyle:w,mergedTheme:v,handleNativeElScroll:R,cssVars:d?void 0:z,themeClass:C?.themeClass,onRender:C?.onRender},$)},render(){var o;const{mergedClsPrefix:r,hasSider:a}=this;(o=this.onRender)===null||o===void 0||o.call(this);const l=a?this.hasSiderStyle:void 0,d=[this.themeClass,e&&`${r}-layout-content`,`${r}-layout`,`${r}-layout--${this.position}-positioned`];return g("div",{class:d,style:this.cssVars},this.nativeScrollbar?g("div",{ref:"scrollableElRef",class:[`${r}-layout-scroll-container`,this.contentClass],style:[this.contentStyle,l],onScroll:this.handleNativeElScroll},this.$slots):g(K,Object.assign({},this.scrollbarProps,{onScroll:this.onScroll,ref:"scrollbarInstRef",theme:this.mergedTheme.peers.Scrollbar,themeOverrides:this.mergedTheme.peerOverrides.Scrollbar,contentClass:this.contentClass,contentStyle:[this.contentStyle,l]}),this.$slots))}})}const Be=oe(!1),we=oe(!0),$e=c("layout-sider",`
 flex-shrink: 0;
 box-sizing: border-box;
 position: relative;
 z-index: 1;
 color: var(--n-text-color);
 transition:
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier),
 min-width .3s var(--n-bezier),
 max-width .3s var(--n-bezier),
 transform .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 background-color: var(--n-color);
 display: flex;
 justify-content: flex-end;
`,[x("bordered",[i("border",`
 content: "";
 position: absolute;
 top: 0;
 bottom: 0;
 width: 1px;
 background-color: var(--n-border-color);
 transition: background-color .3s var(--n-bezier);
 `)]),i("left-placement",[x("bordered",[i("border",`
 right: 0;
 `)])]),x("right-placement",`
 justify-content: flex-start;
 `,[x("bordered",[i("border",`
 left: 0;
 `)]),x("collapsed",[c("layout-toggle-button",[c("base-icon",`
 transform: rotate(180deg);
 `)]),c("layout-toggle-bar",[P("&:hover",[i("top",{transform:"rotate(-12deg) scale(1.15) translateY(-2px)"}),i("bottom",{transform:"rotate(12deg) scale(1.15) translateY(2px)"})])])]),c("layout-toggle-button",`
 left: 0;
 transform: translateX(-50%) translateY(-50%);
 `,[c("base-icon",`
 transform: rotate(0);
 `)]),c("layout-toggle-bar",`
 left: -28px;
 transform: rotate(180deg);
 `,[P("&:hover",[i("top",{transform:"rotate(12deg) scale(1.15) translateY(-2px)"}),i("bottom",{transform:"rotate(-12deg) scale(1.15) translateY(2px)"})])])]),x("collapsed",[c("layout-toggle-bar",[P("&:hover",[i("top",{transform:"rotate(-12deg) scale(1.15) translateY(-2px)"}),i("bottom",{transform:"rotate(12deg) scale(1.15) translateY(2px)"})])]),c("layout-toggle-button",[c("base-icon",`
 transform: rotate(0);
 `)])]),c("layout-toggle-button",`
 transition:
 color .3s var(--n-bezier),
 right .3s var(--n-bezier),
 left .3s var(--n-bezier),
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 cursor: pointer;
 width: 24px;
 height: 24px;
 position: absolute;
 top: 50%;
 right: 0;
 border-radius: 50%;
 display: flex;
 align-items: center;
 justify-content: center;
 font-size: 18px;
 color: var(--n-toggle-button-icon-color);
 border: var(--n-toggle-button-border);
 background-color: var(--n-toggle-button-color);
 box-shadow: 0 2px 4px 0px rgba(0, 0, 0, .06);
 transform: translateX(50%) translateY(-50%);
 z-index: 1;
 `,[c("base-icon",`
 transition: transform .3s var(--n-bezier);
 transform: rotate(180deg);
 `)]),c("layout-toggle-bar",`
 cursor: pointer;
 height: 72px;
 width: 32px;
 position: absolute;
 top: calc(50% - 36px);
 right: -28px;
 `,[i("top, bottom",`
 position: absolute;
 width: 4px;
 border-radius: 2px;
 height: 38px;
 left: 14px;
 transition: 
 background-color .3s var(--n-bezier),
 transform .3s var(--n-bezier);
 `),i("bottom",`
 position: absolute;
 top: 34px;
 `),P("&:hover",[i("top",{transform:"rotate(12deg) scale(1.15) translateY(-2px)"}),i("bottom",{transform:"rotate(-12deg) scale(1.15) translateY(2px)"})]),i("top, bottom",{backgroundColor:"var(--n-toggle-bar-color)"}),P("&:hover",[i("top, bottom",{backgroundColor:"var(--n-toggle-bar-color-hover)"})])]),i("border",`
 position: absolute;
 top: 0;
 right: 0;
 bottom: 0;
 width: 1px;
 transition: background-color .3s var(--n-bezier);
 `),c("layout-sider-scroll-container",`
 flex-grow: 1;
 flex-shrink: 0;
 box-sizing: border-box;
 height: 100%;
 opacity: 0;
 transition: opacity .3s var(--n-bezier);
 max-width: 100%;
 `),x("show-content",[c("layout-sider-scroll-container",{opacity:1})]),x("absolute-positioned",`
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 `)]),ze=L({props:{clsPrefix:{type:String,required:!0},onClick:Function},render(){const{clsPrefix:e}=this;return g("div",{onClick:this.onClick,class:`${e}-layout-toggle-bar`},g("div",{class:`${e}-layout-toggle-bar__top`}),g("div",{class:`${e}-layout-toggle-bar__bottom`}))}}),ke=L({name:"LayoutToggleButton",props:{clsPrefix:{type:String,required:!0},onClick:Function},render(){const{clsPrefix:e}=this;return g("div",{class:`${e}-layout-toggle-button`,onClick:this.onClick},g(ie,{clsPrefix:e},{default:()=>g(ce,null)}))}}),Ie={position:Q,bordered:Boolean,collapsedWidth:{type:Number,default:48},width:{type:[Number,String],default:272},contentClass:String,contentStyle:{type:[String,Object],default:""},collapseMode:{type:String,default:"transform"},collapsed:{type:Boolean,default:void 0},defaultCollapsed:Boolean,showCollapsedContent:{type:Boolean,default:!0},showTrigger:{type:[Boolean,String],default:!1},nativeScrollbar:{type:Boolean,default:!0},inverted:Boolean,scrollbarProps:Object,triggerClass:String,triggerStyle:[String,Object],collapsedTriggerClass:String,collapsedTriggerStyle:[String,Object],"onUpdate:collapsed":[Function,Array],onUpdateCollapsed:[Function,Array],onAfterEnter:Function,onAfterLeave:Function,onExpand:[Function,Array],onCollapse:[Function,Array],onScroll:Function},Re=L({name:"LayoutSider",props:Object.assign(Object.assign({},F.props),Ie),setup(e){const o=de(ee),r=j(null),a=j(null),l=j(e.defaultCollapsed),d=ue(W(e,"collapsed"),l),v=B(()=>Y(d.value?e.collapsedWidth:e.width)),_=B(()=>e.collapseMode!=="transform"?{}:{minWidth:Y(e.width)}),y=B(()=>o?o.siderPlacement:"left");function b(n,t){if(e.nativeScrollbar){const{value:s}=r;s&&(t===void 0?s.scrollTo(n):s.scrollTo(n,t))}else{const{value:s}=a;s&&s.scrollTo(n,t)}}function R(){const{"onUpdate:collapsed":n,onUpdateCollapsed:t,onExpand:s,onCollapse:N}=e,{value:I}=d;t&&E(t,!I),n&&E(n,!I),l.value=!I,I?s&&E(s):N&&E(N)}let w=0,$=0;const z=n=>{var t;const s=n.target;w=s.scrollLeft,$=s.scrollTop,(t=e.onScroll)===null||t===void 0||t.call(e,n)};G(()=>{if(e.nativeScrollbar){const n=r.value;n&&(n.scrollTop=$,n.scrollLeft=w)}}),J(me,{collapsedRef:d,collapseModeRef:W(e,"collapseMode")});const{mergedClsPrefixRef:C,inlineThemeDisabled:u}=X(e),h=F("Layout","-layout-sider",$e,Z,e,C);function p(n){var t,s;n.propertyName==="max-width"&&(d.value?(t=e.onAfterLeave)===null||t===void 0||t.call(e):(s=e.onAfterEnter)===null||s===void 0||s.call(e))}const te={scrollTo:b},A=B(()=>{const{common:{cubicBezierEaseInOut:n},self:t}=h.value,{siderToggleButtonColor:s,siderToggleButtonBorder:N,siderToggleBarColor:I,siderToggleBarColorHover:re}=t,m={"--n-bezier":n,"--n-toggle-button-color":s,"--n-toggle-button-border":N,"--n-toggle-bar-color":I,"--n-toggle-bar-color-hover":re};return e.inverted?(m["--n-color"]=t.siderColorInverted,m["--n-text-color"]=t.textColorInverted,m["--n-border-color"]=t.siderBorderColorInverted,m["--n-toggle-button-icon-color"]=t.siderToggleButtonIconColorInverted,m.__invertScrollbar=t.__invertScrollbar):(m["--n-color"]=t.siderColor,m["--n-text-color"]=t.textColor,m["--n-border-color"]=t.siderBorderColor,m["--n-toggle-button-icon-color"]=t.siderToggleButtonIconColor),m}),k=u?q("layout-sider",B(()=>e.inverted?"a":"b"),A,e):void 0;return Object.assign({scrollableElRef:r,scrollbarInstRef:a,mergedClsPrefix:C,mergedTheme:h,styleMaxWidth:v,mergedCollapsed:d,scrollContainerStyle:_,siderPlacement:y,handleNativeElScroll:z,handleTransitionend:p,handleTriggerClick:R,inlineThemeDisabled:u,cssVars:A,themeClass:k?.themeClass,onRender:k?.onRender},te)},render(){var e;const{mergedClsPrefix:o,mergedCollapsed:r,showTrigger:a}=this;return(e=this.onRender)===null||e===void 0||e.call(this),g("aside",{class:[`${o}-layout-sider`,this.themeClass,`${o}-layout-sider--${this.position}-positioned`,`${o}-layout-sider--${this.siderPlacement}-placement`,this.bordered&&`${o}-layout-sider--bordered`,r&&`${o}-layout-sider--collapsed`,(!r||this.showCollapsedContent)&&`${o}-layout-sider--show-content`],onTransitionend:this.handleTransitionend,style:[this.inlineThemeDisabled?void 0:this.cssVars,{maxWidth:this.styleMaxWidth,width:Y(this.width)}]},this.nativeScrollbar?g("div",{class:[`${o}-layout-sider-scroll-container`,this.contentClass],onScroll:this.handleNativeElScroll,style:[this.scrollContainerStyle,{overflow:"auto"},this.contentStyle],ref:"scrollableElRef"},this.$slots):g(K,Object.assign({},this.scrollbarProps,{onScroll:this.onScroll,ref:"scrollbarInstRef",style:this.scrollContainerStyle,contentStyle:this.contentStyle,contentClass:this.contentClass,theme:this.mergedTheme.peers.Scrollbar,themeOverrides:this.mergedTheme.peerOverrides.Scrollbar,builtinThemeOverrides:this.inverted&&this.cssVars.__invertScrollbar==="true"?{colorHover:"rgba(255, 255, 255, .4)",color:"rgba(255, 255, 255, .3)"}:void 0}),this.$slots),a?a==="bar"?g(ze,{clsPrefix:o,class:r?this.collapsedTriggerClass:this.triggerClass,style:r?this.collapsedTriggerStyle:this.triggerStyle,onClick:this.handleTriggerClick}):g(ke,{clsPrefix:o,class:r?this.collapsedTriggerClass:this.triggerClass,style:r?this.collapsedTriggerStyle:this.triggerStyle,onClick:this.handleTriggerClick}):null,this.bordered?g("div",{class:`${o}-layout-sider__border`}):null)}}),Pe=L({name:"TableSiderLayout",__name:"table-sider-layout",props:{defaultExpanded:{type:Boolean,default:!1},siderTitle:{default:void 0}},setup(e){const o=new Date().getTime(),a=ge(fe).smaller("lg");return(l,d)=>{const v=xe,_=Ce,y=be,b=ye,R=ve,w=Re,$=we,z=Be;return O(a)?(V(),M(R,{key:0,class:"min-h-500px flex-col-stretch gap-16px overflow-auto","x-gap":12,"y-gap":12,"item-responsive":"",responsive:"screen"},{default:f(()=>[T(b,{span:"24 s:24 1034:10 m:8 l:7 xl:6 xxl:5"},{default:f(()=>[T(y,{bordered:!1,size:"small",class:"sider-layout-card h-full card-wrapper","content-class":"sider-layout-card-content"},{default:f(()=>[O(a)?(V(),M(_,{key:0,"default-expanded-names":e.defaultExpanded?[`table-sider-layout${O(o)}`]:[]},{default:f(()=>[T(v,{title:e.siderTitle,name:`table-sider-layout${O(o)}`,"display-directive":"show"},{header:f(()=>[S(l.$slots,"header",{},()=>[H("span",null,U(e.siderTitle),1)],!0)]),"header-extra":f(()=>[S(l.$slots,"header-extra",{},void 0,!0)]),default:f(()=>[S(l.$slots,"sider",{},void 0,!0)]),_:3},8,["title","name"])]),_:3},8,["default-expanded-names"])):he("",!0)]),_:3})]),_:3}),T(b,{class:"content",span:"24 s:24 m:16 l:17 xl:18 xxl:19"},{default:f(()=>[S(l.$slots,"default",{},void 0,!0)]),_:3})]),_:3})):(V(),M(z,{key:1,"has-sider":""},{default:f(()=>[T(w,{"collapse-mode":"transform","collapsed-width":0,width:320,"show-trigger":"bar"},{default:f(()=>[T(y,{bordered:!1,size:"small",class:"sider-layout-card h-full card-wrapper","content-class":"sider-layout-card-content"},{header:f(()=>[S(l.$slots,"header",{},()=>[H("span",null,U(e.siderTitle),1)],!0)]),"header-extra":f(()=>[S(l.$slots,"header-extra",{},void 0,!0)]),default:f(()=>[S(l.$slots,"sider",{},void 0,!0)]),_:3})]),_:3}),T($,{"content-class":"bg-transparent"},{default:f(()=>[S(l.$slots,"default",{},void 0,!0)]),_:3})]),_:3}))}}}),Oe=pe(Pe,[["__scopeId","data-v-5ce479cd"]]);export{Oe as _};
