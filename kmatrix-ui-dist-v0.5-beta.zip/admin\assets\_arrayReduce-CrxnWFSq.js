function g(e,d,n,f){var i=-1,h=e==null?0:e.length;for(f&&h&&(n=e[++i]);++i<h;)n=d(n,e[i],i,e);return n}export{g as a};
