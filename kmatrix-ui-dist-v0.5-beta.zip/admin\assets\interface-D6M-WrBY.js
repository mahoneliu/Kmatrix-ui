import{C as t}from"./main-DpEtK5Yz.js";const e=t("n-layout-sider"),i={type:String,default:"static"};export{e as l,i as p};
